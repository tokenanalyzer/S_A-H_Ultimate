import { useState } from "react";
import { useListContests, useGetScoutStats, useGetGithubRateLimit } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  ExternalLink, Clock, Trophy, Code2, GitFork, AlertTriangle,
  Scan, TrendingUp, Shield, Globe,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";

/* ── Platform display config ─────────────────────────────────────────────── */
const LIVE_PLATFORM_STYLE: Record<string, { badge: string; label: string }> = {
  sherlock:  { badge: "bg-purple-50 text-purple-700 border-purple-200",  label: "Sherlock"  },
  code4rena: { badge: "bg-emerald-50 text-emerald-700 border-emerald-200", label: "Code4rena" },
};

const STATUS_STYLE: Record<string, string> = {
  active:   "bg-green-50 text-green-700 border-green-200",
  upcoming: "bg-amber-50 text-amber-700 border-amber-200",
  ended:    "bg-gray-100 text-gray-500 border-gray-200",
};

/* ── KYC-friendly curated platforms ──────────────────────────────────────── */
interface CuratedProgram {
  id: string;
  name: string;
  description: string;
  url: string;
  badge: string;
  badgeLabel: string;
  kycNote: string;
  maxBounty: string;
  tags: string[];
}

const CURATED_PLATFORMS: CuratedProgram[] = [
  {
    id: "immunefi",
    name: "Immunefi",
    description: "Largest Web3 bug bounty platform. India-friendly KYC — accepts Aadhaar + PAN for identity verification. Payouts in USDC, ETH, or BTC.",
    url: "https://immunefi.com/bug-bounty/",
    badge: "bg-red-50 text-red-700 border-red-200",
    badgeLabel: "Immunefi",
    kycNote: "India KYC ✓",
    maxBounty: "Up to $10M",
    tags: ["DeFi", "Smart Contracts", "Bridges", "Layer 2"],
  },
  {
    id: "hackenproof",
    name: "HackenProof",
    description: "Professional security research platform with blockchain focus. KYC via Sumsub — accepts Indian government IDs. Crypto & fiat payouts available.",
    url: "https://hackenproof.com/programs",
    badge: "bg-blue-50 text-blue-700 border-blue-200",
    badgeLabel: "HackenProof",
    kycNote: "India KYC ✓",
    maxBounty: "Up to $1M",
    tags: ["Solidity", "Rust", "Blockchain"],
  },
  {
    id: "cantina",
    name: "Cantina",
    description: "Competitive audit platform by Spearbit alumni. Global researcher pool, merit-based rewards. No restrictive KYC — standard identity verification.",
    url: "https://cantina.xyz/competitions",
    badge: "bg-indigo-50 text-indigo-700 border-indigo-200",
    badgeLabel: "Cantina",
    kycNote: "India KYC ✓",
    maxBounty: "Varies per contest",
    tags: ["DeFi", "Protocols", "EVM"],
  },
  {
    id: "spearbit",
    name: "Spearbit",
    description: "Elite security research network for top-tier protocols. Invitation-based — build a track record on Code4rena/Sherlock to qualify. Remote-friendly globally.",
    url: "https://spearbit.com/",
    badge: "bg-cyan-50 text-cyan-700 border-cyan-200",
    badgeLabel: "Spearbit",
    kycNote: "India KYC ✓",
    maxBounty: "Premium rates",
    tags: ["Elite", "Invite-Only", "DeFi"],
  },
];

function formatPrize(n: number | null): string {
  if (!n) return "—";
  return n >= 1000 ? `$${(n / 1000).toFixed(0)}K` : `$${n}`;
}

function timeLeft(end: string): string {
  const diff = new Date(end).getTime() - Date.now();
  if (diff < 0) return "Ended";
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  return d > 0 ? `${d}d ${h}h left` : `${h}h left`;
}

export default function RadarPage() {
  const [platform, setPlatform] = useState<"all" | "sherlock" | "code4rena">("all");
  const [status, setStatus]     = useState<"all" | "active" | "upcoming" | "ended">("active");
  const [, navigate]            = useLocation();

  const { data: contests = [], isLoading } = useListContests(
    { platform, status } as Parameters<typeof useListContests>[0]
  );
  const { data: stats }     = useGetScoutStats();
  const { data: rateLimit } = useGetGithubRateLimit();

  return (
    <div className="space-y-8">

      {/* ── Live contest section header ──────────────────────────────────── */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Contest Radar</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Live audit opportunities — Sherlock &amp; Code4rena · India-friendly platforms below
          </p>
        </div>
        {rateLimit && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground bg-white border border-border rounded-lg px-3 py-2"
            style={{ boxShadow: "0 1px 3px rgba(0,0,0,0.05)" }}>
            <GitFork className="h-3.5 w-3.5" />
            <span>GitHub: {rateLimit.remaining}/{rateLimit.limit}</span>
            {rateLimit.authenticated && <span className="text-green-600 font-medium">auth'd</span>}
            {rateLimit.remaining < 10 && <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />}
          </div>
        )}
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "Active Contests",   value: stats.totalActive,                                              color: "text-green-600",  icon: TrendingUp },
            { label: "Upcoming",          value: stats.totalUpcoming,                                            color: "text-amber-600",  icon: Clock      },
            { label: "Total Prize Pool",  value: formatPrize(stats.totalPrizePool),                             color: "text-emerald-600",icon: Trophy     },
            { label: "Sherlock / C4",     value: `${stats.byPlatform.sherlock} / ${stats.byPlatform.code4rena}`, color: "text-purple-600", icon: Code2      },
          ].map(({ label, value, color, icon: Icon }) => (
            <div key={label} className="bg-white rounded-xl border border-border p-4"
              style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.05)" }}>
              <div className="flex items-center gap-2 mb-2">
                <Icon className={cn("h-4 w-4", color)} />
                <span className="text-xs text-muted-foreground font-medium">{label}</span>
              </div>
              <p className={cn("text-xl font-bold", color)}>{value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Platform + status filters */}
      <div className="flex flex-wrap gap-2">
        <div className="flex gap-1 bg-white border border-border rounded-lg p-1"
          style={{ boxShadow: "0 1px 3px rgba(0,0,0,0.05)" }}>
          {(["all", "sherlock", "code4rena"] as const).map((p) => (
            <Button key={p} size="sm" variant={platform === p ? "default" : "ghost"}
              className={cn("text-xs h-7 rounded-md", platform !== p && "text-muted-foreground")}
              onClick={() => setPlatform(p)}>
              {p === "all" ? "All" : p === "sherlock" ? "Sherlock" : "Code4rena"}
            </Button>
          ))}
        </div>
        <div className="flex gap-1 bg-white border border-border rounded-lg p-1"
          style={{ boxShadow: "0 1px 3px rgba(0,0,0,0.05)" }}>
          {(["active", "upcoming", "ended", "all"] as const).map((s) => (
            <Button key={s} size="sm" variant={status === s ? "default" : "ghost"}
              className={cn("text-xs h-7 rounded-md capitalize", status !== s && "text-muted-foreground")}
              onClick={() => setStatus(s)}>
              {s}
            </Button>
          ))}
        </div>
      </div>

      {/* Contest grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-white rounded-xl border border-border p-4 animate-pulse space-y-3"
              style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.05)" }}>
              <div className="h-4 bg-gray-100 rounded w-3/4" />
              <div className="h-3 bg-gray-100 rounded w-1/2" />
              <div className="h-3 bg-gray-100 rounded w-2/3" />
            </div>
          ))}
        </div>
      ) : contests.length === 0 ? (
        <div className="text-center py-14 bg-white rounded-xl border border-border"
          style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.05)" }}>
          <Trophy className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">No contests match the selected filters</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {contests.map((contest) => {
            const ps = LIVE_PLATFORM_STYLE[contest.platform] ?? LIVE_PLATFORM_STYLE.sherlock;
            return (
              <div key={contest.id}
                className="bg-white rounded-xl border border-border p-4 flex flex-col gap-3 hover:border-primary/40 transition-all duration-150 group"
                style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.05)" }}>

                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-semibold text-foreground leading-snug flex-1 min-w-0 truncate">
                    {contest.title}
                  </p>
                  <a href={contest.repoUrl} target="_blank" rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-primary transition-colors shrink-0"
                    onClick={(e) => e.stopPropagation()}>
                    <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <span className={cn("text-xs font-medium px-2 py-0.5 rounded-full border", ps.badge)}>
                    {ps.label}
                  </span>
                  <span className={cn("text-xs font-medium px-2 py-0.5 rounded-full border capitalize", STATUS_STYLE[contest.status])}>
                    {contest.status}
                  </span>
                  <span className="text-xs bg-green-50 text-green-700 border border-green-200 px-2 py-0.5 rounded-full font-medium">
                    India KYC ✓
                  </span>
                  {contest.prizePool && (
                    <span className="ml-auto text-sm font-bold text-emerald-600">{formatPrize(contest.prizePool)}</span>
                  )}
                </div>

                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />{timeLeft(contest.endDate)}
                  </span>
                  {contest.nsloc && (
                    <span className="flex items-center gap-1">
                      <Code2 className="h-3 w-3" />{contest.nsloc.toLocaleString()} nSLOC
                    </span>
                  )}
                </div>

                {contest.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {contest.tags.slice(0, 4).map((t) => (
                      <span key={t} className="text-xs bg-gray-50 border border-gray-200 text-gray-500 px-1.5 py-0.5 rounded">
                        {t}
                      </span>
                    ))}
                  </div>
                )}

                <Button size="sm" variant="outline"
                  className="w-full text-xs h-8 mt-auto group-hover:border-primary group-hover:text-primary transition-colors"
                  onClick={() => navigate(`/scanner?repo=${encodeURIComponent(contest.repoUrl)}`)}>
                  <Scan className="h-3 w-3 mr-1.5" /> Scan This Repo
                </Button>
              </div>
            );
          })}
        </div>
      )}

      {/* ── KYC-Friendly Platform Directory ─────────────────────────────── */}
      <div className="space-y-4 pt-4">
        <div className="flex items-center gap-3">
          <div className="h-px flex-1 bg-border" />
          <div className="flex items-center gap-2 px-3">
            <Shield className="h-4 w-4 text-primary" />
            <span className="text-sm font-semibold text-foreground whitespace-nowrap">
              India-Friendly KYC Platforms
            </span>
            <Globe className="h-4 w-4 text-muted-foreground" />
          </div>
          <div className="h-px flex-1 bg-border" />
        </div>
        <p className="text-xs text-muted-foreground text-center">
          Verified bug bounty &amp; audit platforms accepting Indian researchers — KYC via Aadhaar, PAN, or Passport
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {CURATED_PLATFORMS.map((prog) => (
            <div key={prog.id}
              className="bg-white rounded-xl border border-border p-4 flex flex-col gap-3 hover:border-primary/40 transition-all duration-150 group"
              style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.05)" }}>

              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className={cn("text-xs font-semibold px-2 py-0.5 rounded-full border", prog.badge)}>
                    {prog.badgeLabel}
                  </span>
                  <span className="text-xs bg-green-50 text-green-700 border border-green-200 px-2 py-0.5 rounded-full font-medium">
                    {prog.kycNote}
                  </span>
                </div>
                <a href={prog.url} target="_blank" rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors shrink-0">
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </div>

              <p className="text-sm font-semibold text-foreground">{prog.name}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{prog.description}</p>

              <div className="flex items-center justify-between pt-1">
                <div className="flex flex-wrap gap-1">
                  {prog.tags.map((t) => (
                    <span key={t} className="text-xs bg-gray-50 border border-gray-200 text-gray-500 px-1.5 py-0.5 rounded">
                      {t}
                    </span>
                  ))}
                </div>
                <span className="text-xs font-semibold text-emerald-600 shrink-0 ml-2">{prog.maxBounty}</span>
              </div>

              <a href={prog.url} target="_blank" rel="noopener noreferrer"
                className="w-full text-xs h-8 mt-auto flex items-center justify-center gap-1.5 rounded-lg border border-border text-muted-foreground hover:border-primary hover:text-primary transition-colors bg-white group-hover:border-primary group-hover:text-primary">
                <Globe className="h-3 w-3" /> View Programs
              </a>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
