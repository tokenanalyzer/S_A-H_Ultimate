import { Router, type IRouter } from "express";
import healthRouter from "./health";
import scoutRouter from "./scout";
import harvesterRouter from "./harvester";
import analysisRouter from "./analysis";

const router: IRouter = Router();

router.use(healthRouter);
router.use(scoutRouter);
router.use(harvesterRouter);
router.use(analysisRouter);

export default router;
